#!/usr/bin/env python3
"""
PNG File Rename Script

This script renames all PNG files in a specified folder by adding a timestamp prefix.
Files are renamed from "image.png" to "2024-06-29_12-34-56_image.png"

Usage: python script.py
"""

import os
from pathlib import Path
from datetime import datetime

def main():
    # Get the current directory (you can change this to a specific folder)
    folder_path = Path(".")
    
    print(f"Looking for PNG files in: {folder_path.absolute()}")
    
    # Find all PNG files
    png_files = list(folder_path.glob("*.png"))
    
    if not png_files:
        print("No PNG files found.")
        return
    
    print(f"Found {len(png_files)} PNG file(s)")
    
    renamed_count = 0
    for file_path in png_files:
        try:
            # Get file modification time
            mod_time = datetime.fromtimestamp(file_path.stat().st_mtime)
            timestamp = mod_time.strftime("%Y-%m-%d_%H-%M-%S")
            
            # Create new filename
            new_name = f"{timestamp}_{file_path.name}"
            new_path = file_path.parent / new_name
            
            # Rename the file
            file_path.rename(new_path)
            print(f"✓ Renamed: {file_path.name} → {new_name}")
            renamed_count += 1
            
        except Exception as e:
            print(f"✗ Error renaming {file_path.name}: {e}")
    
    print(f"\nComplete! Renamed {renamed_count} file(s)")

if __name__ == "__main__":
    main()
