#!/usr/bin/env python3
"""
CSV Cleaner Script

This script removes duplicate rows and rows with blank values from a CSV file.
Reads from input.csv and writes clean data to output_clean.csv

Usage: python script.py
"""

import csv
from pathlib import Path

def main():
    input_file = Path("input.csv")
    output_file = Path("output_clean.csv")
    
    if not input_file.exists():
        print(f"Error: {input_file} not found")
        return
    
    print(f"Reading {input_file}...")
    
    try:
        # Read the CSV file
        rows = []
        headers = None
        with open(input_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames
            
            for row in reader:
                rows.append(row)
        
        print(f"Initial rows: {len(rows)}")
        
        # Remove rows with any blank values
        cleaned_rows = [row for row in rows if all(value.strip() for value in row.values())]
        removed_blank = len(rows) - len(cleaned_rows)
        print(f"Removed rows with blanks: {removed_blank}")
        
        # Remove duplicate rows
        unique_rows = []
        seen = set()
        for row in cleaned_rows:
            row_tuple = tuple(sorted(row.items()))
            if row_tuple not in seen:
                seen.add(row_tuple)
                unique_rows.append(row)
        
        removed_dupes = len(cleaned_rows) - len(unique_rows)
        print(f"Removed duplicate rows: {removed_dupes}")
        
        # Write clean data
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(unique_rows)
        
        print(f"\nClean rows: {len(unique_rows)}")
        print(f"Saved to: {output_file}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
