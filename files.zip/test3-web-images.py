#!/usr/bin/env python3
"""
Web Image Downloader

This script downloads all images from a website and saves them to a local folder.
Creates an 'images' folder in the current directory.

Requires: pip install requests beautifulsoup4

Usage: python script.py
"""

import os
import requests
from pathlib import Path
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

def main():
    url = input("Enter website URL (e.g., https://example.com): ").strip()
    
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    
    print(f"Fetching {url}...")
    
    try:
        # Fetch the webpage
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        # Parse HTML
        soup = BeautifulSoup(response.content, 'html.parser')
        img_tags = soup.find_all('img')
        
        if not img_tags:
            print("No images found on this page.")
            return
        
        print(f"Found {len(img_tags)} image(s)")
        
        # Create output folder
        output_folder = Path("images")
        output_folder.mkdir(exist_ok=True)
        
        downloaded = 0
        for idx, img in enumerate(img_tags, 1):
            try:
                img_url = img.get('src') or img.get('data-src')
                if not img_url:
                    continue
                
                # Handle relative URLs
                img_url = urljoin(url, img_url)
                
                # Download image
                img_response = requests.get(img_url, timeout=5)
                img_response.raise_for_status()
                
                # Save image
                parsed_url = urlparse(img_url)
                filename = Path(parsed_url.path).name or f"image_{idx}.jpg"
                filepath = output_folder / filename
                
                with open(filepath, 'wb') as f:
                    f.write(img_response.content)
                
                print(f"✓ Downloaded: {filename}")
                downloaded += 1
                
            except Exception as e:
                print(f"✗ Error downloading image {idx}: {e}")
        
        print(f"\nComplete! Downloaded {downloaded} image(s) to '{output_folder}'")
        
    except requests.exceptions.RequestException as e:
        print(f"Error fetching webpage: {e}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
