#!/usr/bin/env python3
"""
Word Counter Script

This script counts all words in text files (.txt) within a folder.
Provides a count per file and a total count.

Usage: python script.py
"""

from pathlib import Path

def main():
    folder_path = Path(".")
    
    print(f"Counting words in text files...\n")
    
    # Find all text files
    text_files = list(folder_path.glob("*.txt"))
    
    if not text_files:
        print("No .txt files found in current folder.")
        return
    
    total_words = 0
    for file_path in text_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                word_count = len(content.split())
                total_words += word_count
                print(f"  {file_path.name}: {word_count:,} words")
        except Exception as e:
            print(f"  Error reading {file_path.name}: {e}")
    
    print(f"\nTotal words across all files: {total_words:,}")

if __name__ == "__main__":
    main()
