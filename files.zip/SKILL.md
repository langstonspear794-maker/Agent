---
name: python-scripts
description: Generate ready-to-run Python scripts for automation and practical tasks. Use this whenever a user—especially someone new to Python—asks for help automating a workflow, processing data, scraping a website, managing files, or solving a practical problem with code. They may not know Python syntax or how to structure a solution; your job is to produce a complete, working script they can run immediately without modification. Trigger even if the user phrases it casually ("how do I...") or doesn't explicitly say "write a script"—if it's a practical task that Python can solve, use this skill.
compatibility: Python 3.8+
---

# Python Scripts for Beginners

A skill for generating working Python scripts that solve practical automation and data problems for users with little or no coding experience.

## Core Philosophy

- **Complete and runnable:** The script works out of the box with no tweaks needed
- **Pragmatic:** Use whatever libraries and approaches are most appropriate, even if it means external dependencies
- **Self-contained:** Each script handles its own setup, error handling, and feedback to the user
- **Cross-platform:** Assume Windows, Mac, and Linux unless told otherwise
- **Helpful output:** The script should tell the user what it's doing and report results clearly

## When to Use This Skill

Use this skill when:
- A user wants to automate a task (file operations, scheduling, batch processing)
- A user needs to process or extract data (cleaning, transformation, web scraping)
- A user wants to build a practical tool but doesn't know where to start
- A user describes a problem that Python can solve, even if they don't ask for code explicitly
- A user is new to programming or Python and needs guidance on *how to structure* a solution

Do NOT use this skill if:
- The user is asking to learn Python concepts (that's teaching, not task automation)
- The user already has working code and just needs debugging help
- The user is building a production system or needs architectural guidance

## Script Design Principles

### 1. Structure & Clarity
- Use a simple main() function with clear sections
- Add comments at the top explaining what the script does and any setup needed
- Group related operations together
- Keep functions focused and reusable where it makes sense

### 2. Handling Dependencies
- Prefer Python's built-in standard library (os, sys, json, csv, datetime, etc.)
- Use popular third-party packages when they significantly improve the solution:
  - `requests` for HTTP requests
  - `pandas` for data processing
  - `beautifulsoup4` for web scraping
  - `python-dotenv` for environment variables
  - `schedule` for task scheduling
- Always include a comment at the top if external packages are needed, e.g.:
  ```python
  # Requires: pip install requests beautifulsoup4
  ```

### 3. Error Handling
- Wrap file operations in try/except blocks
- Catch common errors (FileNotFoundError, ConnectionError, etc.)
- Print clear error messages so the user knows what went wrong
- Don't silently fail—report progress and results

### 4. User Interaction
- Print clear status messages ("Processing...", "Found 42 files", "Complete!")
- Ask for input only when necessary (file paths, configuration)
- Provide sensible defaults where possible
- Report what the script did at the end

### 5. Cross-Platform Compatibility
- Use `os.path.join()` instead of hardcoded "/" or "\\" for file paths
- Use `pathlib.Path` for modern, clean path handling
- Avoid platform-specific commands or assumptions
- Test mentally for Windows, Mac, and Linux

## Common Script Patterns

### File & Directory Operations
```python
import os
from pathlib import Path

def process_files(directory):
    for filepath in Path(directory).glob("*.txt"):
        # process file
```

### Data Processing
```python
import csv
import json

# Read CSV
with open("data.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        # process row
```

### Web Requests
```python
import requests

response = requests.get(url)
if response.status_code == 200:
    data = response.json()
    # process data
```

### Scheduling (if needed)
```python
import schedule
import time

def job():
    # do something
    
schedule.every().day.at("10:30").do(job)

while True:
    schedule.run_pending()
    time.sleep(60)
```

## Testing & Validation

Before delivering a script, mentally test it:
- [ ] Does it run without syntax errors?
- [ ] Does it handle missing files or network failures gracefully?
- [ ] Will it work on Windows, Mac, and Linux?
- [ ] Are all external dependencies listed in a comment?
- [ ] Does the user know what to do with the output?
- [ ] Is there a clear "done" message?

## Example Output

When you generate a script, format it like this:

```python
#!/usr/bin/env python3
"""
[Script Description]

This script [what it does]. 
[Any setup required]

Requires: pip install [packages if any]
Usage: python script_name.py
"""

import os
import sys
from pathlib import Path

def main():
    print("Starting...")
    # logic here
    print("Done!")

if __name__ == "__main__":
    main()
```

## Customization

If the user provides specifics:
- **Input format:** Use the format they specify (CSV, JSON, directories, URLs, etc.)
- **Output format:** Create output in the format they need (CSV, JSON, text file, console output, etc.)
- **Performance:** If they mention large datasets, use efficient approaches (generators, chunking, etc.)
- **Frequency:** If they want it to run repeatedly, add scheduling or make it loop-aware

---

## Common Scenarios

### "How do I rename all files in a folder?"
→ Generate a script that safely renames files with confirmation or dry-run option

### "I have a CSV with messy data, can you clean it?"
→ Generate a script that reads the CSV, applies transformations, and writes a clean output

### "I want to download images from a website"
→ Generate a script using requests + BeautifulSoup that fetches and saves images

### "Can you help me organize my downloads?"
→ Generate a script that sorts files by type, date, or custom rules into folders

### "I need to monitor a folder for new files"
→ Generate a script using watchdog or polling that alerts when files arrive

---

End of skill guide. When a user asks for a Python script, generate the complete, working code directly—don't explain or theorize, just deliver the script ready to run.
