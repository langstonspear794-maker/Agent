#!/usr/bin/env python3
"""
Folder Organizer Script

This script organizes files in a folder by file type into subfolders.
Files stay in place, only folders are created to organize them.

Usage: python script.py
"""

import os
from pathlib import Path
from shutil import move

def main():
    folder_path = Path(".").resolve()
    
    print(f"Organizing files in: {folder_path}")
    
    # File type categories
    categories = {
        "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
        "Documents": [".pdf", ".doc", ".docx", ".txt", ".xlsx", ".csv", ".ppt", ".pptx"],
        "Audio": [".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"],
        "Video": [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv"],
        "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
        "Code": [".py", ".js", ".html", ".css", ".java", ".cpp", ".c", ".go", ".rs"]
    }
    
    # Create folders and organize files
    moved_count = 0
    for category, extensions in categories.items():
        category_folder = folder_path / category
        
        for file_path in folder_path.glob("*"):
            if file_path.is_file() and file_path.suffix.lower() in extensions:
                try:
                    # Create category folder if it doesn't exist
                    category_folder.mkdir(exist_ok=True)
                    
                    # Move file
                    dest_path = category_folder / file_path.name
                    move(str(file_path), str(dest_path))
                    print(f"✓ Moved: {file_path.name} → {category}/")
                    moved_count += 1
                    
                except Exception as e:
                    print(f"✗ Error moving {file_path.name}: {e}")
    
    print(f"\nComplete! Organized {moved_count} file(s)")

if __name__ == "__main__":
    main()
